// project automatic slider // 

(function gridAutoSlider(root) {
  const viewport = root.querySelector('.project_slider__viewport');
  const track = root.querySelector('.project_slider__track');
  // const prevBtn = root.querySelector('.slider__btn--prev');
  // const nextBtn = root.querySelector('.slider__btn--next');
  const dotsWrap = root.querySelector('.slider__dots');

  let index = 0; // current left-most slide index
  let perView = getPerView();
  let total = track.children.length;
  let autoTimer = null;
  let isPaused = false;

  // Build dots (one per "page")
  function pagesCount() {
    return Math.max(1, Math.ceil(total / perView));
  }
  function buildDots() {
    dotsWrap.innerHTML = '';
    for (let i = 0; i < pagesCount(); i++) {
      const dot = document.createElement('button');
      dot.type = 'button';
      dot.className = 'slider__dot';
      dot.addEventListener('click', () => goTo(i * perView));
      dotsWrap.appendChild(dot);
    }
    updateDots();
  }

  function getPerView() {
    // Read the CSS variable that media queries adjust
    const styles = window.getComputedStyle(root);
    const v = parseInt(styles.getPropertyValue('--per-view'));
    return Math.max(1, v || 1);
  }

  function slideWidth() {
    return viewport.clientWidth / perView; // each grid column width in px
  }

  function updateTransform() {
    const x = -index * slideWidth();
    track.style.transform = `translate3d(${x}px, 0, 0)`;
    updateDots();
  }

  function updateDots() {
    const page = Math.round(index / perView);
    [...dotsWrap.children].forEach((d, i) => d.setAttribute('aria-current', i === page));
  }

  function clampIndex(i) {
    const max = Math.max(0, total - perView);
    if (i < 0) return 0;
    if (i > max) return max;
    return i;
  }

  function goTo(i) {
    index = clampIndex(i);
    updateTransform();
  }

  function next() { goTo(index + 1); }
  function prev() { goTo(index - 1); }

  // Autoplay with wrap-around
  function startAutoplay() {
    stopAutoplay();
    const delay = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--slide-delay')) || 1600;
    const duration = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--slide-duration')) || 2600;
    autoTimer = setInterval(() => {
      if (isPaused) return;
      const atEnd = index >= total - perView;
      if (atEnd) {
        // jump back to start instantly (no transition), then animate to 1
        track.style.transition = 'none';
        index = 0;
        updateTransform();
        // force reflow to apply the no-transition jump
        void track.offsetWidth;
        track.style.transition = '';
      }
      next();
    }, delay + duration);
  }
  function stopAutoplay() { if (autoTimer) clearInterval(autoTimer); }

  // Pause on hover/focus
  root.addEventListener('mouseenter', () => { isPaused = true; });
  root.addEventListener('mouseleave', () => { isPaused = false; });
  root.addEventListener('focusin', () => { isPaused = true; });
  root.addEventListener('focusout', () => { isPaused = false; });

  // Buttons
  // prevBtn.addEventListener('click', () => { prev(); });
  // nextBtn.addEventListener('click', () => { next(); });

  // Drag / touch swipe (basic)
  let startX = 0, dragging = false;
  viewport.addEventListener('pointerdown', (e) => {
    dragging = true; startX = e.clientX; viewport.setPointerCapture(e.pointerId);
  });
  viewport.addEventListener('pointermove', (e) => {
    if (!dragging) return;
    const dx = e.clientX - startX;
    track.style.transition = 'none';
    const x = -index * slideWidth() + dx;
    track.style.transform = `translate3d(${x}px, 0, 0)`;
  });
  viewport.addEventListener('pointerup', (e) => {
    if (!dragging) return;
    dragging = false; track.style.transition = '';
    const dx = e.clientX - startX;
    if (Math.abs(dx) > slideWidth() / 4) {
      dx < 0 ? next() : prev();
    } else {
      updateTransform();
    }
  });

  // Handle resize / orientation changes
  const ro = new ResizeObserver(() => {
    const prevPerView = perView;
    perView = getPerView();
    if (perView !== prevPerView) {
      // realign index to page boundary to avoid half-cards after responsive change
      index = Math.floor(index / perView) * perView;
    }
    updateTransform();
    buildDots();
  });
  ro.observe(viewport);

  // init
  buildDots();
  updateTransform();
  startAutoplay();

})
  (document.getElementById('autoGridSlider'));